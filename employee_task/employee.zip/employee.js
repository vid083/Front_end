var basicSalary = document.getElementById("b").value;
/*function salary(basicSalary){*/
function hra(basicSalary){
    var hra_value = basicSalary.value;
    document.getElementById("c").value = hra_value;

    var medicalAllowance = basicSalary.value/3;
    document.getElementById("d").value = medicalAllowance;

    var conveyanceAllowance = basicSalary.value/2;
    document.getElementById("e").value = conveyanceAllowance;

    var telephoneAllowance = basicSalary.value/1.5;
    document.getElementById("f").value = telephoneAllowance;

    var otherAllowance = 0.025 * basicSalary.value;
    document.getElementById("g").value = otherAllowance;

    var pf = 0.25 * basicSalary.value;
    document.getElementById("h").value = pf;

    var professionalTax = 200;
    document.getElementById("i").value = professionalTax;

    var incomeTax = 1.04 *(basicSalary.value*12);
    document.getElementById("j").value = incomeTax;
    
    var allowances = (basicSalary.value + hra_value + medicalAllowance + conveyanceAllowance + telephoneAllowance + otherAllowance) ;
        // + conveyanceAllowance + telephoneAllowance + otherAllowance) - (pf + professionalTax + incomeTax)  ;
    var deductions = pf + professionalTax + incomeTax;

        document.getElementById("k").value = parseFloat(allowances)-parseFloat(deductions);

}


